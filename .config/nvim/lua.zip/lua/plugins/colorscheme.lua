return {
  'Mofiqul/dracula.nvim',
  {
    "LazyVim/LazyVim",
    opts = {
      colorscheme = "dracula",
    },
  }
}
