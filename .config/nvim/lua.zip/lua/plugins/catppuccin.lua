return {
  -- disable catppuccin
  {
    "catppuccin/nvim",
    enabled = false
  },
}
