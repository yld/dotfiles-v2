return {
  { 'tpope/vim-rails', },
  { 'tpope/vim-fugitive', },
  { 'tpope/vim-surround', },
}
