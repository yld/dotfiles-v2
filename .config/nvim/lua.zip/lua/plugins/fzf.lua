return {
  'junegunn/fzf.vim',
  enabled = false,
  require = {
    'junegunn/fzf',
    run = ':call fzf#install()'
  }
}
