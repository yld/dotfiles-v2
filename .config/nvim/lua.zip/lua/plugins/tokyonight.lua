return {
  -- disable tokyonight
  {
    "folke/tokyonight.nvim",
    enabled = false
  },
}
