return {
  -- disable catppuccin
  {
    "nvim-lualine/lualine.nvim",
    options = { theme = 'dracula' }
  }
}
